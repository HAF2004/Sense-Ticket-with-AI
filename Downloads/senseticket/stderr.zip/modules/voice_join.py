# modules/voice_join.py
# Voice join cog for specific user

import discord
from discord.ext import commands
from core.config import SPECIAL_USER_ID

class VoiceJoinCog(commands.Cog):
    """
    Handles voice join when specific user tags bot
    """
    def __init__(self, bot):
        self.bot = bot
        
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        """
        Join voice channel when specific user mentions bot
        """
        # Check if specific user
        if message.author.id != SPECIAL_USER_ID:
            return
        
        # Check if bot is mentioned
        if not (self.bot.user.mentioned_in(message) and not message.mention_everyone):
            return


async def setup(bot):
    """
    Setup function for cog
    """
    await bot.add_cog(VoiceJoinCog(bot))
    print("  🔊 Voice Join cog loaded")
